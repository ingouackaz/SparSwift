//: > **Important**: En suivant la formation Sparswift vous acceptez de passer des centaines d'heures face à des problèmes qui peuvent être résolu en quelques seconde par un confirmé ( moi même ).  SparSwift ne sera pas tenu responsable en cas de maux de tête, vomissement, spasme ou violence cerebrale, . Bon courage !

//: # Apprendre l'essentiel en Swift
//:
//: L'apprentissage du Swift comme tout language est un apprentissage qui nécessite beaucoup de cours mais surtout beaucoup de pratique. Dans cet formation , nous accentuerons la pratique du Swift grâce à une panopelis d'exerice qui viendront illustrer les concepts appris au prélable.

//: ## Sommaire
//:
//:
//: * Variables
//:
//: * Opérateurs
//:
//: * Fonctions
//:
//: * Conditions
//:
//:
//:
//:
//: [Suivant](@next)


