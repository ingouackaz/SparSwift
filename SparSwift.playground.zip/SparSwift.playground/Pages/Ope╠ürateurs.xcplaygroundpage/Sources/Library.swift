import Foundation

public func SparSwift_correct_my_exercice_0(num:Int){
    
    if (num == (89 * 12)){
        print("Exercice [0] - ACCOMPLI :)")
    }
    else {
        print("Exercice [0] - ÉCHOUÉ :(")
        
    }
}
