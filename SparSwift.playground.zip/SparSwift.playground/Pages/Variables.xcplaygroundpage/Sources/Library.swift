import Foundation


var formatExOutput : String = ""

public func SparSwift_correct_my_exercice_0(str:String){

    print("------ Niveau 0 -----\n")
    print(" Roger  : \"Soldat, qui somme nous ?\"")
    print(" Soldats : \"\(str)\"")
    if (str == "LES SPARSWIFT  !!!!!!!"){
        print(" Roger  : Exactement !")

        print("\nStatus : ✅")
    }
    else {
        print(" Roger  : 😡😡😡 Pardon !???")
        print("\nStatus : ❌")
    }
    print("\n\n")
}


// END


// Demo:



public func SparSwift_correct_my_exercice_1(str:String){
    
    print("------ Niveau 1 -----")
    print("\n")
    print(" Roger : SOLDATS ! Quel est notre profession ?")
    print(" Soldats : \" \(str)\"")

    if (str == "AOUH AOUH !!!!"){
        print(" Roger  : C'est ce que je voulais entendre !")

        print("\nStatus : ✅")
    }
    else {
        print(" Roger  : ... !")

        print("Status : ❌")
    }
    print("\n\n")

}

public func SparSwift_correct_my_exercice_2(bool:Bool){
    
    print("------ Exercice 2 -----")
    print("\n")
    print(" Roger : Le Swift pour vous c'est cool ?")
    
    if (bool == true){
        print(" Soldats : \" OUI CHEF ! LE SWIFT C'EST COOL !\"")

        print("\nStatus : ✅")
    }
    else {
        print(" Soldats : \" NON CHEF ! C'EST DE LA M*****!\"")

        print("Status : ❌")
    }
}


public func SparSwift_correct_my_exercice_3(num:Int){
  
    // consigne  : Créez une variable qu'on appellera num de type Int qui contiendra la valeur 23

    if (num == 21){
        print("Exercice [3] - ACCOMPLI - BlackJack !")
    }
    else {
        print("Exercice [3] - ÉCHOUÉ :(")
        
    }
}

public func SparSwift_correct_my_exercice_4(taille:Double){
    
    if (taille == 1.80){
        print("Exercice [4] - ACCOMPLI :)")
    }
    else {
        print("Exercice [4] - ÉCHOUÉ :(")
        
    }
}

public func SparSwift_correct_my_exercice_5(name:String,lastName:String){
    
    if (name == "Roger" && lastName == "Federer"){
        print("Exercice [5] - ACCOMPLI :)")
    }
    else {
        print("Exercice [5] - ÉCHOUÉ :(")
        
    }
}

public func SparSwift_correct_my_exercice_6(name:String,lastName:String,anneeNaissance:Int,taille:Double,poids:Int){
    

    print("Bonjour \(name) ou devrais-je dire Mr \(lastName), comment allez-vous ?")
    
    let age : Int =  2016 - anneeNaissance
    
    if (anneeNaissance > 2016){
        print("Sympa votre année de naissance vous venez du futur ?  :) ")
    }
    else {
        print("Pour vos \(age) nous vous préparons une belle surprise !")
    }
    if (taille > 2.4){
        print("Êtes-vous sur de bien avoir renseigner une taille humaine ?")
    }
    else if(taille < 0.6){
        print("Oh !!! Un minimoyls !!! Cava mon petit bout ?")
    }
    else {
        print("Vous faites exactement vos \(taille) mètre et \(poids) soit les mensurations idéal pour notre petit bijoux ;)")
    }


}

public func SparSwift_correct_my_exercice_7(answer:Bool){
    
    if (answer == true){
        print("Exercice [7] - ACCOMPLI :)")
    }
    else {
        print("Exercice [7] - ÉCHOUÉ :(")
        
    }
}

public func SparSwift_correct_my_exercice_8(answer:Bool){
    
    if (answer == true){
        print("Exercice [8] - ACCOMPLI :)")
    }
    else {
        print("Exercice [8] - ÉCHOUÉ :(")
        
    }
}

public func SparSwift_correct_my_exercice_9(answer:Bool){
    
    if (answer == true){
        print("Exercice [9] - ACCOMPLI :)")
    }
    else {
        print("Exercice [9] - ÉCHOUÉ :(")
        
    }
}

public func SparSwift_correct_my_exercice_10(answer:Bool){
    
    if (answer == true){
        print("Exercice [10] - ACCOMPLI :)")
    }
    else {
        print("Exercice [10] - ÉCHOUÉ :(")
        
    }
}


public func SparSwift_correct_my_exercice_11(answer:Bool){
    
    if (answer == true){
        print("Exercice [11] - ACCOMPLI :)")
    }
    else {
        print("Exercice [11] - ÉCHOUÉ :(")
        
    }
}

public func SparSwift_correct_my_exercice_12(answer:Bool){
    
    if (answer == true){
        print("Exercice [12] - ACCOMPLI :)")
    }
    else {
        print("Exercice [12] - ÉCHOUÉ :(")
        
    }
}

public func SparSwift_correct_my_exercice_13(answer:Bool){
    
    if (answer == true){
        print("Exercice [13] - ACCOMPLI :)")
    }
    else {
        print("Exercice [13] - ÉCHOUÉ :(")
        
    }
}

public func SparSwift_correct_my_exercice_14(answer:Bool){
    
    if (answer == true){
        print("Exercice [14] - ACCOMPLI :)")
    }
    else {
        print("Exercice [14] - ÉCHOUÉ :(")
        
    }
}
